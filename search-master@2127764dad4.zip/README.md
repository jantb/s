# Search
kotlin search for k8

## Local install
`mvn clean install package && mv target/s-1.0-SNAPSHOT-jar-with-dependencies.jar ../bin/s.jar`

## Miljøvariabler

`kubeconfig=/c/dev/.kube/config`

# Manual
Bruk av applikasjonen forutsetter at man er logget inn via oc login 

## VELGE POD/TOPIC
**ctrl + k** : vis/skjul kafka-køer\
**ctrl + p** : vis/skjul podder \
**ctrl + pil opp/pil down** : velg tidsvindu for kafka (i kafka-visning)\
**enter/ctrl + A** : velg podder/topics 
  

## NAVIGERING
**shift + klikk** : åpne melding\
**ctrl + scroll** : zoom\
**scroll** : endre offset fra bunnen\
**pil opp/ned** : endre offset fra bunnen med +/- 1\
**page-up/ page down** ;  endre offset fra bunnen med +/- 1/2 sider\
**enter** : set offset til 0
  

## OPERASJONER
**ctrl + shift + klikk** : send melding på lokal kø 


## SØK/FILTRERING
* fritekst
* ord omkranset med "" betyr eksakt frase
* ord med space mellom benytter AND 
* ! for å filtrere vekk  
**ctrl + klikk** : søk/filtrer på valgt string\
**ctrl + h** : skjul "heavy hitters", dvs. meldingsstruktur form som utgjør mer enn 10 % av totalt av logg/meldinger for gitt pod/topic (bruker punkt fra splunk for å determinere struktur)

