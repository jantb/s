package util


import net.openhft.hashing.LongHashFunction
import util.Bf.Companion.estimate
import java.io.Serializable
import java.util.BitSet
import kotlin.math.ceil
import kotlin.math.ln
import kotlin.math.min
import kotlin.math.pow

class Index<T>(
    private val probability: Double = 0.01,
    private val goalCardinality: Double = 0.10,
) : Serializable {
    private var shards: MutableMap<Int, Shard<T>> = HashMap()
    private var isHigherRank: Boolean = false
    var size: Int = 0
    val countGrams: CountMin = CountMin()


    fun add(key: T, value: String) {
        require(!isHigherRank) {
            "Can not add values to a higher rank index"
        }
        if (value.isBlank()) {
            return
        }

        val grams = value.grams()
        val estimate = estimate(grams.size, probability)

        shards.computeIfAbsent(estimate) {
            Shard(estimate)
        }.add(grams, key)
        size++
    }

    fun search(value: String): List<T> {
        val grams = value.grams()
        return shards.values.map { it.search(listOf(grams)) }.flatten()
    }

    fun searchOr(valueList: List<String>): Set<T> {
        return valueList.map { search(it) }
            .fold<List<T>, MutableList<T>>(mutableListOf()) { acc, i -> acc.addAll(i);acc }.toSet()
    }

    fun searchMustInclude(valueListList: List<List<String>>): List<T> {
        // Must include all the strings in each of the lists
        val gramsList = valueListList.map { stringList -> stringList.map { it.grams() }.flatten().distinct() }
        return shards.values.map { it.search(gramsList) }.flatten()
    }

    fun convertToHigherRank() {
        require(!isHigherRank) {
            "Can not convert an already converted higher rank"
        }
        isHigherRank = true
        shards.forEach { it.value.convertToHigherRankRows(goalCardinality) }
    }
}

class Shard<T>(
    m: Int,
    private val valueList: MutableList<T> = mutableListOf(),
    private val rows: Array<Row> = Array(m) { Row() },
    private val bf: Bf = Bf(m),
    private var isHigherRank: Boolean = false
) : Serializable {
    fun add(gramList: List<String>, key: T) {
        gramList.forEach { g ->
            bf.bitSet.clear()
            bf.add(g, 1)
            bf.bitSet.getAllSetBitPositions().forEach {
                rows[it].setBit(valueList.size)
            }
        }
        valueList.add(key)
    }

    fun convertToHigherRankRows(goalCardinality: Double) {
        require(!isHigherRank) {
            "Can not convert an already converted higher rank"
        }
        isHigherRank = true
        rows.forEach {
            it.expandToFitBit(valueList.size)
            it.convertToTargetDensity(goalCardinality)
        }
    }

    fun search(gramsList: List<List<String>>): List<T> {
        if (gramsList.flatten().isEmpty()) {
            return valueList
        }

        val bitPositions = gramsList.filter { it.isNotEmpty() }.map { getRows(it) }
        return getSetValues(bitPositions)
    }

    private fun getRows(
        grams: List<String>,
    ): List<Row> {
        bf.bitSet.clear()
        grams.forEach {
            bf.add(it, 1)
        }

        return bf.bitSet.getAllSetBitPositions().map { rows[it] }.toList()
    }

    private fun getSetValues(bitPositions: List<List<Row>>): List<T> {
        val values = mutableListOf<T>()
        val map = bitPositions.map {
            andRowsOfNotEqualLength(it)
        }

        // send in ORed values, generate bit positions and ranks, merge here and collect Ored results
        map.groupBy { it.rank }.values.map {
            it.reduce { acc, row ->
                acc.or(row)
                acc
            }
        }.forEach { row ->
            if (!row.isEmpty()) {
                for (i in 0 until (1 shl row.rank))
                    BitSet.valueOf(row.words).getAllSetBitPositions()
                        .forEach {
                            val index = it + row.wordsInUse * i * Long.SIZE_BITS
                            // in case we have a higher rank row with hit on index late in the row, and there is not a value for it in the valueList
                            if (index < valueList.size && index >= 0) {
                                values.add(valueList[index])
                            }
                        }
            }
        }

        return values
    }

    private fun andRowsOfNotEqualLength(
        relevantRows: List<Row>,
    ): Row {
        val rows = relevantRows.sortedByDescending { it.rank }

        val res = Row()
        res.or(rows[0])
        res.rank = rows[0].rank
        var currentRank = rows[0].rank

        for (i in 1 until rows.size) {
            val row = rows[i]
            while (currentRank != row.rank) {
                res.doubleWords()
                currentRank--
            }
            res.and(row)
            if (res.isEmpty()) {
                return res
            }
        }
        return res
    }
}

class Bf(private val m: Int) : Serializable {
    val bitSet = BitSet(m)
    fun add(s: String, hashes: Int) {
        if (hashes == 0) {
            return
        }

        val splitLong = splitLong(LongHashFunction.xx3().hashChars(s))
        (1..hashes).forEach {
            bitSet.set((splitLong.first.toLong() + splitLong.second.toLong() * it) mod m)
        }
    }

    private infix fun Long.mod(m: Int) = Math.floorMod(this, m)

    private fun splitLong(number: Long): Pair<Int, Int> {
        val lower32 = number.and(0xFFFFFFFF).toInt()
        val upper32 = number.shr(32).toInt()
        return lower32 to upper32
    }

    companion object {
        fun estimate(n: Int, p: Double): Int {
            val roundUpto = 1024
            return (ceil((n * ln(p)) / ln(1.0 / 2.0.pow(ln(2.0)))).toInt() + roundUpto - 1) / roundUpto * roundUpto
        }
    }
}

class Row(initialSize: Int = 1) : Serializable {
    var words = LongArray(initialSize)
    var size = words.size
    var wordsInUse = 0
    var rank = 0

    fun convertToTargetDensity(targetDensity: Double) {
        if (targetDensity < 0.0 || targetDensity > 1.0) {
            throw IllegalArgumentException("Target density should be between 0.0 and 1.0.")
        }

        while (words.size > 1) {
            val length = words.size
            val partSize = length / 2

            val newArray = LongArray(partSize) {
                words[it] or words[it + partSize]
            }


            words = newArray
            size = words.size
            recalculateWordsInUseFrom(words.size)
            rank++
            if (newArray.calculateDensity() >= targetDensity) {
                break
            }
        }
    }

    fun setBit(bitToSet: Int) {
        if (bitToSet < 0) {
            throw IllegalArgumentException("Bit index should be non-negative.")
        }

        expandToFitBit(bitToSet)

        val originalIndex = bitToSet / java.lang.Long.SIZE
        words[originalIndex] = words[originalIndex] or (1L shl (bitToSet % java.lang.Long.SIZE))
    }

    fun expandToFitBit(bitToSet: Int) {
        if (bitToSet < 0) {
            throw IllegalArgumentException("Bit index should be non-negative.")
        }
        if (words.isEmpty()) {
            words = LongArray(1)
        }
        var partSize = words.size / (1 shl 0)
        while (bitToSet >= partSize * java.lang.Long.SIZE) {
            growWords()
            partSize *= 2
        }
        wordsInUse = (bitToSet / 64) + 1
    }

    private fun growWords() {
        val newArray = LongArray(words.size * 2)
        System.arraycopy(words, 0, newArray, 0, words.size)
        words = newArray
    }

    fun doubleWords() {
        val newArray = LongArray(words.size * 2)
        System.arraycopy(words, 0, newArray, 0, words.size)
        System.arraycopy(words, 0, newArray, words.size, words.size)
        wordsInUse += words.size
        words = newArray
    }

    fun isEmpty(): Boolean {
        return wordsInUse == 0
    }

    private fun recalculateWordsInUse() {
        // Traverse the bitset until a used word is found
        while (wordsInUse > 0) {
            if (words[wordsInUse - 1] != 0L) break
            wordsInUse--
        }
    }

    internal fun recalculateWordsInUseFrom(index: Int) {
        // Traverse the bitset until a used word is found
        wordsInUse = index
        while (wordsInUse > 0) {
            if (words[wordsInUse - 1] != 0L) break
            wordsInUse--
        }
    }

    fun or(row: Row) {
        val wordsInCommon = min(wordsInUse, row.wordsInUse)
        if (wordsInUse < row.wordsInUse) {
            ensureCapacity(row.wordsInUse)
            wordsInUse = row.wordsInUse
        }

        // Perform logical OR on words in common
        for (i in 0 until wordsInCommon) words[i] = words[i] or row.words[i]

        // Copy any remaining words
        if (wordsInCommon < row.wordsInUse) System.arraycopy(
            row.words, wordsInCommon,
            words, wordsInCommon,
            wordsInUse - wordsInCommon
        )
    }

    private fun ensureCapacity(wordsRequired: Int) {
        if (words.size < wordsRequired) {
            // Allocate larger of doubled size or required size
            val request = (2 * words.size).coerceAtLeast(wordsRequired)
            words = words.copyOf(request)
        }
    }

    fun and(row: Row) {
        val min = min(wordsInUse, row.wordsInUse)

        for (i in 0 until min) words[i] = words[i] and row.words[i]

        recalculateWordsInUseFrom(min)
    }
}

fun LongArray.calculateDensity() = sumOf { java.lang.Long.bitCount(it) }.toDouble() / (size * java.lang.Long.SIZE)

fun BitSet.getAllSetBitPositions(): Sequence<Int> {
    return generateSequence(this.nextSetBit(0)) { setBit ->
        this.nextSetBit(setBit + 1).takeIf { it >= 0 }
    }
}

fun String.grams(): List<String> {
    val lowercase = lowercase().filter { it.isLetterOrDigit() }
    return lowercase.windowed(3, 1).distinct() + lowercase.windowed(2, 1).distinct() + lowercase.windowed(1, 1)
        .distinct()
}

class CountMin(epsOfTotalCount: Double = 0.0001, confidence: Double = 0.99) {
    val width: Int
    val depth: Int
    var docCount = 0
    private var count = 0

    init {
        val calculateWidthAndDepth = calculateWidthAndDepth(epsOfTotalCount, confidence)
        width = calculateWidthAndDepth.first
        depth = calculateWidthAndDepth.second
    }

    private val sketch = Array(depth) { IntArray(width) }
    val size = width * depth

    fun add(item: String) {
        count++
        val hashes = hash(item)
        for (i in 0 until depth) {
            sketch[i][(hashes[i] mod width)]++
        }
    }

    fun count(item: String): Int {
        val hashes = hash(item)
        var countMin = Int.MAX_VALUE
        for (i in 0 until depth) {
            countMin = minOf(countMin, sketch[i][(hashes[i] mod width)])
        }
        return countMin
    }


    fun topKSetAbove(item: String, threshold: Double = 0.1): Boolean {
        return (count * threshold) < count(item)
    }


    private fun calculateWidthAndDepth(
        epsOfTotalCount: Double, confidence: Double
    ): Pair<Int, Int> {

        val width = ceil(2 / epsOfTotalCount).toInt()
        val depth = ceil(-ln(1 - confidence) / ln(2.0)).toInt()

        return width to depth
    }

    private fun hash(item: String): LongArray {
        val splitLong = splitLong(LongHashFunction.xx3().hashChars(item))
        val hashes = LongArray(depth)
        (0 until depth).forEach {
            hashes[it] = (splitLong.first.toLong() + splitLong.second.toLong() * it)
        }

        return hashes
    }

    private fun splitLong(number: Long): Pair<Int, Int> {
        val lower32 = number.and(0xFFFFFFFF).toInt()
        val upper32 = number.shr(32).toInt()
        return lower32 to upper32
    }

    private infix fun Long.mod(m: Int): Int {
        return Math.floorMod(this, m)
    }
}