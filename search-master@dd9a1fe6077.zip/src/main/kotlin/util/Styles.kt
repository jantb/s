package util

object Styles {
    val monoFont = "JetBrainsMono Nerd Font Mono"
    val normalFont = "JetBrainsMono Nerd Font"
}